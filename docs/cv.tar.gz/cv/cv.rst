.. -*- rst -*-
.. -*-  coding: utf-8 -*-

.. role:: smallcaps
.. role:: smallemph

.. default-role::


.. |CV| replace:: :smallcaps:`CV`
.. |RST| replace:: :smallcaps:`RST`


Écrivain d'articles sur internet
================================

:moderncvstyle: classic
:moderncvcolor: blue

:Author:        John Doe
:address:       123 rue des fleurs
                12345 Ma ville

:mobile:        06 78 91 23 45
:email:         contact@exemple.com
:homepage:      blog.chimrod.com

:extrainfo:     1982 (33 ans)


.. |nbsp| unicode:: 0xA0
	:trim:

Expériences
-----------

:Depuis 2011:

    **Mon poste** - *Ma boîte* - À côté de chez moi.

    Je fais plein de choses.

    Je fais également ça.

:2010 - 2011:

    **Mon ancien poste** - *Mon ancienne boîte* - Plus loin de chez moi.

    J'ai fait beaucoup de choses aussi.

:2010:

    **Un autre poste** - *Encore une boîte* - Ailleurs.

    I was here.

:2008 - 2010:

    **Mon premier poste** - *Ma première entreprise* - Paris.

    Je suis ému quand j'y repense.


Compétences
-----------


:Domaine:

    Je sais écrire de beaux |CV|, je peux écrire des articles sur mon blog
    également (je fais pleins d'articles sur le |rst|)

:Programmation:

    Objet (Java, Python), Fonctionnel (OCaml)

:Système d'exploitation:

    Administration Linux (Debian), auto-hébergement de mon blog.

Formation
---------

:2008:

    **Mon dernier diplôme** - *Université de France*

    après j'ai arrêté.

:2006:

    **Un autre diplôme** - *Université de Navarre*

    il faut que j'aille le chercher depuis ce temps…

:2005:

    **Encore un** - *Université*

    mention " |nbsp| Assez bien |nbsp| "

:2001:

    **Mon premier diplôme** - *Lycée* - Loin de chez moi aujourd'hui

    J'étais jeune à l'époque.


Centres d'intérêts
------------------

:Loisirs:

    Logiciel libre, Musique, Philosophie.

